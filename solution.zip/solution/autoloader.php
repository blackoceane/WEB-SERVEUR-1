<?php
register_autoloaders();

function register_autoloaders()
{
    spl_autoload_register('autoload_dao');
    spl_autoload_register('autoload_modeles');
}

function autoload_dao($class)
{
    // echo "DAO : $class\n";
    $fichier = 'dao/'.$class.'.php';
    if (is_readable($fichier))
    {
        require_once $fichier;
    }
}

function autoload_modeles($class)
{
    // echo "Modèle : $class\n";
    $fichier = 'modeles/'.$class.'.php';
    if (is_readable($fichier))
    {
        require_once $fichier;
    }
}
