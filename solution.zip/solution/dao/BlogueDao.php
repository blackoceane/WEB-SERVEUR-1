<?php

class BlogueDao extends BaseDao
{
    private UtilisateurDao $utilisateurDao;
    private ArticleDao $articleDao;

    public function __construct(ConfigDao $config)
    {
        parent::__construct($config);
        $this->utilisateurDao = new UtilisateurDao($config);
        $this->articleDao = new ArticleDao($config);
    }

    public function selectAll() : array
    {
        $connexion = $this->getConnexion();

        $requete = $connexion->prepare("SELECT * FROM blogue");
        $requete->execute();

        $blogues = [];
        while ($enregistrement = $requete->fetch())
        {
            $blogue = $this->construireBlogue($enregistrement);
            $blogue->setBlogueur($this->utilisateurDao->select($blogue->getBlogueurId()));
            $blogues[] = $blogue;
        }

        return $blogues;
    }

    public function select(int $id): ?Blogue
    {
        $connexion = $this->getConnexion();

        $requete = $connexion->prepare("SELECT * FROM blogue WHERE id=:id");
        $requete->bindValue(":id", $id);
        $requete->execute();

        $blogue = null;
        if ($enregistrement = $requete->fetch())
        {
            $blogue = $this->construireBlogue($enregistrement);
            $blogue->setBlogueur($this->utilisateurDao->select($blogue->getBlogueurId()));
            $blogue->setArticles($this->articleDao->selectAllParUtilisateurId($blogue->getBlogueurId()));
        }

        return $blogue;
    }

    public function selectParBlogueurId(int $blogueurId): ?Blogue
    {
        $connexion = $this->getConnexion();

        $requete = $connexion->prepare("SELECT * FROM blogue WHERE utilisateur_id=:utilisateur_id");
        $requete->bindValue(":utilisateur_id", $blogueurId);
        $requete->execute();

        $blogue = null;
        if ($enregistrement = $requete->fetch())
        {
            $blogue = $this->construireBlogue($enregistrement);
            $blogue->setBlogueur($this->utilisateurDao->select($blogue->getBlogueurId()));
            $blogue->setArticles($this->articleDao->selectAllParUtilisateurId($blogue->getBlogueurId()));
        }

        return $blogue;
    }

    private function construireBlogue($enregistrement): Blogue
    {
        return new Blogue(
            $enregistrement['nom'],
            $enregistrement['description'],
            $enregistrement['utilisateur_id'],
            new DateTime($enregistrement['date_creation']),
            $enregistrement['id']
        );
    }
}