<?php

class ArticleDao extends BaseDao
{
    private CommentaireDao $commentaireDao;
    private UtilisateurDao $utilisateurDao;

    public function __construct(ConfigDao $config)
    {
        parent::__construct($config);
        $this->commentaireDao = new CommentaireDao($config);
        $this->utilisateurDao = new UtilisateurDao($config);
    } 

    public function selectAllParUtilisateurId(int $utilisateurId): array
    {
        $connexion = $this->getConnexion();

        $requete = $connexion->prepare("SELECT * FROM article WHERE utilisateur_id=:utilisateur_id ORDER BY date_creation ASC");
        $requete->bindValue(":utilisateur_id", $utilisateurId);
        $requete->execute();

        $articles = [];
        while ($enregistrement = $requete->fetch())
        {
            $articles[] = $this->construireArticle($enregistrement);
        }

        return $articles;
    }

    public function select(int $id): ?Article
    {
        $connexion = $this->getConnexion();

        $requete = $connexion->prepare("SELECT * FROM article WHERE id=:id");
        $requete->bindValue(":id", $id);
        $requete->execute();

        $article = null;
        if ($enregistrement = $requete->fetch())
        {
            $article = $this->construireArticle($enregistrement);
            $this->recupererTags($article);
            $article->setCommentaires($this->commentaireDao->selectAllParArticleId($article->getId()));
            $article->setAuteur($this->utilisateurDao->select($article->getAuteurId()));
        }

        return $article;
    }

    public function insert(Article $article): void
    {
        $connexion = $this->getConnexion();
        try
        {
            $connexion->beginTransaction();

            $requete = $connexion->prepare("INSERT INTO article(titre, texte, date_creation, date_modification, publie, utilisateur_id) VALUES(:titre, :texte, NOW(), NOW(), :publie, :utilisateur_id)");
            $requete->bindValue(":titre", $article->getTitre());
            $requete->bindValue(":texte", $article->getTexte());
            $requete->bindValue(":publie", $article->isPublie(), PDO::PARAM_BOOL);
            $requete->bindValue(":utilisateur_id", $article->getAuteurId());
            $requete->execute();

            $id = $connexion->lastInsertId();
            $article->setId($id);

            // Nous passons la connexion afin que le tout soit dans la même transaction
            $this->majTagsArticle($article, $connexion);

            $connexion->commit();
        }
        catch (PDOException $e)
        {
            $connexion->rollBack();
            throw $e;
        }
    }

    public function update(Article $article): void
    {
        $connexion = $this->getConnexion();
        try
        {
            $connexion->beginTransaction();

            $requete = $connexion->prepare("UPDATE article SET titre=:titre, texte=:texte, date_modification=NOW(), publie=:publie WHERE id=:id");
            $requete->bindValue(":titre", $article->getTitre());
            $requete->bindValue(":texte", $article->getTexte());
            $requete->bindValue(":publie", $article->isPublie(), PDO::PARAM_BOOL);
            $requete->bindValue(":id", $article->getId());
            $requete->execute();

            // Nous passons la connexion afin que le tout soit dans la même transaction
            $this->majTagsArticle($article, $connexion);

            $connexion->commit();
        }
        catch (PDOException $e)
        {
            $connexion->rollBack();
            throw $e;
        }
    }

    public function delete(int $id): void
    {
        $connexion = $this->getConnexion();
        try
        {
            $connexion->beginTransaction();

            $requete = $connexion->prepare("DELETE FROM article WHERE id=:id");
            $requete->bindValue(":id", $id);
            $requete->execute();

            $connexion->commit();
        }
        catch (PDOException $e)
        {
            $connexion->rollBack();
            throw $e;
        }
    }

    private function construireArticle($enregistrement): Article
    {
        return new Article(
            $enregistrement["titre"],
            $enregistrement["texte"],
            $enregistrement["utilisateur_id"],
            $enregistrement["publie"],
            new DateTime($enregistrement["date_creation"]),
            new DateTime($enregistrement["date_modification"]),
            $enregistrement["id"]
        );
    }

    private function recupererTags(Article $article): void
    {
        $connexion = $this->getConnexion();

        $requete = $connexion->prepare("SELECT * FROM article_tag INNER JOIN tag ON tag_id = id WHERE article_id=:article_id ORDER BY nom ASC");
        $requete->bindValue(":article_id", $article->getId());
        $requete->execute();

        while ($enregistrement = $requete->fetch())
        {
            $article->ajouterTag(new Tag($enregistrement["nom"], $enregistrement["id"]));
        }
    }

    private function majTagsArticle(Article $article, PDO $connexion): void
    {
        // Dans un premier temps, suppression des anciens tags
        $requete = $connexion->prepare("DELETE FROM article_tag WHERE article_id=:article_id");
        $requete->bindValue(":article_id", $article->getId());
        $requete->execute();

        // Dans un deuxième temps, ajout des nouveaux tags
        $requete = $connexion->prepare("INSERT INTO article_tag(article_id, tag_id) VALUES(:article_id, :tag_id)");
        foreach ($article->getTags() as $tag)
        {
            $requete->bindValue(":article_id", $article->getId());
            $requete->bindValue(":tag_id", $tag->getId());
            $requete->execute();
        }
    }
}
