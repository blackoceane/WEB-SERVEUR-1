<?php

class CommentaireDao extends BaseDao
{
    private UtilisateurDao $utilisateurDao;

    public function __construct(ConfigDao $config)
    {
        parent::__construct($config);
        $this->utilisateurDao = new UtilisateurDao($config);
    }

    public function selectAllParArticleId(int $articleId): array
    {
        $connexion = $this->getConnexion();

        $requete = $connexion->prepare("SELECT * FROM commentaire WHERE article_id=:article_id ORDER BY date_publication ASC");
        $requete->bindValue(":article_id", $articleId);
        $requete->execute();

        $commentaires = [];
        while ($enregistrement = $requete->fetch())
        {
            $commentaires[] = $this->construireCommentaire($enregistrement);
        }

        $this->recupererUtilisateurs($commentaires);

        return $commentaires;
    }

    public function insert(Commentaire $commentaire): void
    {
        $connexion = $this->getConnexion();
        try
        {
            $connexion->beginTransaction();

            $requete = $connexion->prepare("INSERT INTO commentaire(texte, date_publication, article_id, utilisateur_id) VALUES(:texte, NOW(), :article_id, :utilisateur_id)");
            $requete->bindValue(":texte", $commentaire->getTexte());
            $requete->bindValue(":article_id", $commentaire->getArticleId());
            $requete->bindValue(":utilisateur_id", $commentaire->getAuteurId());
            $requete->execute();

            $id = $connexion->lastInsertId();

            $connexion->commit();

            $commentaire->setId($id);
        }
        catch (PDOException $e)
        {
            $connexion->rollBack();
            throw $e;
        }
    }

    public function delete(int $id): void
    {
        $connexion = $this->getConnexion();
        try
        {
            $connexion->beginTransaction();

            $requete = $connexion->prepare("DELETE FROM commentaire WHERE id=:id");
            $requete->bindValue(":id", $id);
            $requete->execute();

            $connexion->commit();
        }
        catch (PDOException $e)
        {
            $connexion->rollBack();
            throw $e;
        }
    }

    private function construireCommentaire($enregistrement): Commentaire
    {
        return new Commentaire(
            $enregistrement['texte'],
            $enregistrement['utilisateur_id'],
            $enregistrement['article_id'],
            new DateTime($enregistrement['date_publication']),
            $enregistrement['id']
        );
    }

    private function recupererUtilisateurs(array $commentaires): void
    {
        foreach ($commentaires as $commentaire)
        {
            $commentaire->setAuteur($this->utilisateurDao->select($commentaire->getAuteurId()));
        }
    }
}
