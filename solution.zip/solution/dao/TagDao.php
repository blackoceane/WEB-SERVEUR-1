<?php

/**
 * Classe concrète pour le DAO de la table tag en BD. 
 * 
 * Elle permet les opérations CRUDL pour cette table.
 */
class TagDao extends BaseDao
{
    function __construct(ConfigDao $config)
    {
        parent::__construct($config);
    }

    public function selectAll(): array
    {
        $connexion = $this->getConnexion();

        $requete = $connexion->prepare("SELECT * FROM tag ORDER BY nom ASC");
        $requete->execute();

        $tags = array();
        while ($enregistrement = $requete->fetch())
        {
            $tag = new Tag($enregistrement['nom'], $enregistrement['id']);
            $tags[] = $tag;
        }

        return $tags;
    }

    public function select(int $id): ?Tag
    {
        $connexion = $this->getConnexion();

        $requete = $connexion->prepare("SELECT * FROM tag WHERE id=:id");
        $requete->bindValue(":id", $id);
        $requete->execute();

        $tag = null;
        if ($enregistrement = $requete->fetch())
        {
            $tag = new Tag($enregistrement['nom'], $enregistrement['id']);
        }

        return $tag;
    }

    public function insert(Tag $tag): void
    {
        $connexion = $this->getConnexion();
        try
        {
            $connexion->beginTransaction();

            $requete = $connexion->prepare("INSERT INTO tag(nom) VALUE(:nom)");
            $requete->bindValue(":nom", $tag->getNom());
            $requete->execute();

            $id = $connexion->lastInsertId();

            $connexion->commit();

            $tag->setId($id);
        }
        catch (PDOException $e)
        {
            $connexion->rollBack();
            throw $e;
        }
    }

    public function update(Tag $tag): void
    {
        $connexion = $this->getConnexion();
        try
        {
            $connexion->beginTransaction();

            $requete = $connexion->prepare("UPDATE tag SET nom=:nom WHERE id=:id");
            $requete->bindValue(":nom", $tag->getNom());
            $requete->bindValue(":id", $tag->getId());
            $requete->execute();

            $connexion->commit();
        }
        catch (PDOException $e)
        {
            $connexion->rollBack();
            throw $e;
        }
    }

    public function delete(int $id): void
    {
        $connexion = $this->getConnexion();
        try
        {
            $connexion->beginTransaction();

            $requete = $connexion->prepare("DELETE FROM tag WHERE id=:id");
            $requete->bindValue(":id", $id);
            $requete->execute();

            $connexion->commit();
        }
        catch (PDOException $e)
        {
            $connexion->rollBack();
            throw $e;
        }
    }
}
