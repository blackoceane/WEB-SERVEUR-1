<?php

class Commentaire
{
    private int $id;
    private string $texte;
    private ?DateTime $datePublication;
    private int $auteurId; // L'id de l'utilisateur qui a écrit le commentaire
    private ?Utilisateur $auteur; // L'utilisateur qui a écrit le commentaire
    private int $articleId; // L'id de l'article sur lequel porte le commentaire

    public function __construct(string $texte, int $auteurId, int $articleId, ?DateTime $datePublication = null, int $id = 0)
    {
        $this->setId($id);
        $this->setTexte($texte);
        $this->setDatePublication($datePublication);
        $this->setAuteurId($auteurId);
        $this->setArticleId($articleId);
        $this->setAuteur(null);
    }

    /**
     * Get the value of id
     *
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * Set the value of id
     *
     * @param int $id
     *
     * @return self
     */
    public function setId(int $id): self
    {
        $this->id = $id;
        return $this;
    }

    /**
     * Get the value of texte
     *
     * @return string
     */
    public function getTexte(): string
    {
        return $this->texte;
    }

    /**
     * Set the value of texte
     *
     * @param string $texte
     *
     * @return self
     */
    public function setTexte(string $texte): self
    {
        $texte = trim($texte);
        if (empty($texte) || strlen($texte) > 65535)
            throw new Exception("Le texte '$texte' doit être entre 1 et 65535 caractères.");
        $this->texte = $texte;
        return $this;
    }

    /**
     * Get the value of datePublication
     *
     * @return ?DateTime
     */
    public function getDatePublication(): ?DateTime
    {
        return $this->datePublication;
    }

    /**
     * Set the value of datePublication
     *
     * @param ?DateTime $datePublication
     *
     * @return self
     */
    public function setDatePublication(?DateTime $datePublication): self
    {
        $this->datePublication = $datePublication;
        return $this;
    }

    /**
     * Get the value of auteurId
     *
     * @return int
     */
    public function getAuteurId(): int
    {
        return $this->auteurId;
    }

    /**
     * Set the value of auteurId
     *
     * @param int $auteurId
     *
     * @return self
     */
    public function setAuteurId(int $auteurId): self
    {
        $this->auteurId = $auteurId;
        return $this;
    }

    /**
     * Get the value of auteur
     *
     * @return ?Utilisateur
     */
    public function getAuteur(): ?Utilisateur
    {
        return $this->auteur;
    }

    /**
     * Set the value of auteur
     *
     * @param ?Utilisateur $auteur
     *
     * @return self
     */
    public function setAuteur(?Utilisateur $auteur): self
    {
        $this->auteur = $auteur;
        return $this;
    }

    /**
     * Get the value of articleId
     *
     * @return int
     */
    public function getArticleId(): int
    {
        return $this->articleId;
    }

    /**
     * Set the value of articleId
     *
     * @param int $articleId
     *
     * @return self
     */
    public function setArticleId(int $articleId): self
    {
        $this->articleId = $articleId;
        return $this;
    }
}
