<?php

class Blogue
{
    private int $id;
    private string $nom;
    private string $description;
    private ?DateTime $dateCreation;
    private int $blogueurId;
    private ?Utilisateur $blogueur;
    private array $articles;

    public function __construct(
        string $nom,
        string $description,
        int $blogueurId,
        ?DateTime $dateCreation = null,
        int $id = 0
    )
    {
        $this->setId($id);
        $this->setNom($nom);
        $this->setDescription($description);
        $this->setBlogueurId($blogueurId);
        $this->setDateCreation($dateCreation);
        $this->articles = array();
        $this->setBlogueur(null);
    }


    /**
     * Get the value of id
     *
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * Set the value of id
     *
     * @param int $id
     *
     * @return self
     */
    public function setId(int $id): self
    {
        $this->id = $id;
        return $this;
    }

    /**
     * Get the value of nom
     *
     * @return string
     */
    public function getNom(): string
    {
        return $this->nom;
    }

    /**
     * Set the value of nom
     *
     * @param string $nom
     *
     * @return self
     */
    public function setNom(string $nom): self
    {
        $nom = trim($nom);
        if (empty($nom) || strlen($nom) > 255)
            throw new Exception("Le nom '$nom' du blogue doit être entre 1 et 255 caractères.");
        $this->nom = $nom;
        return $this;
    }

    /**
     * Get the value of description
     *
     * @return string
     */
    public function getDescription(): string
    {
        return $this->description;
    }

    /**
     * Set the value of description
     *
     * @param string $description
     *
     * @return self
     */
    public function setDescription(string $description): self
    {
        $description = trim($description);
        if (empty($description) || strlen($description) > 65535)
            throw new Exception("La description '$description' doit être entre 1 et 65535 caractères.");
        $this->description = $description;
        return $this;
    }

    /**
     * Get the value of dateCreation
     *
     * @return ?DateTime
     */
    public function getDateCreation(): ?DateTime
    {
        return $this->dateCreation;
    }

    /**
     * Set the value of dateCreation
     *
     * @param ?DateTime $dateCreation
     *
     * @return self
     */
    public function setDateCreation(?DateTime $dateCreation): self
    {
        $this->dateCreation = $dateCreation;
        return $this;
    }

    /**
     * Get the value of blogueurId
     *
     * @return int
     */
    public function getBlogueurId(): int
    {
        return $this->blogueurId;
    }

    /**
     * Set the value of blogueurId
     *
     * @param int $blogueurId
     *
     * @return self
     */
    public function setBlogueurId(int $blogueurId): self
    {
        $this->blogueurId = $blogueurId;
        return $this;
    }

    /**
     * Get the value of blogueur
     *
     * @return ?Utilisateur
     */
    public function getBlogueur(): ?Utilisateur
    {
        return $this->blogueur;
    }

    /**
     * Set the value of blogueur
     *
     * @param ?Utilisateur $blogueur
     *
     * @return self
     */
    public function setBlogueur(?Utilisateur $blogueur): self
    {
        $this->blogueur = $blogueur;
        return $this;
    }

    /**
     * Get the value of articles
     *
     * @return array
     */
    public function getArticles(): array
    {
        return $this->articles;
    }

    /**
     * Set the value of articles
     *
     * @param array $articles
     *
     * @return self
     */
    public function setArticles(array $articles): self
    {
        $this->articles = $articles;
        return $this;
    }

    public function ajouterArticle(Article $article)
    {
        $this->articles[] = $article;
    }
}
