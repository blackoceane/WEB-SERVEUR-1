<?php

class Utilisateur
{
    private int $id;
    private string $nomUtilisateur;
    private string $prenom;
    private string $nom;
    private string $courriel;
    private int $roleId;
    private ?Role $role;
    private ?string $cheminAvatar;
    private string $hash;


    public function __construct(string $nomUtilisateur, string $nom, string $prenom, string $courriel, int $roleId, string $hash, ?string $cheminAvatar = null, int $id = 0)
    {
        $this->setId($id);
        $this->setNomUtilisateur($nomUtilisateur);
        $this->setNom($nom);
        $this->setPrenom($prenom);
        $this->setCourriel($courriel);
        $this->setRoleId($roleId);
        $this->setCheminAvatar($cheminAvatar);
        $this->setHash($hash);
        $this->role = null;
    }


    /**
     * Get the value of id
     *
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * Set the value of id
     *
     * @param int $id
     *
     * @return self
     */
    public function setId(int $id): self
    {
        $this->id = $id;
        return $this;
    }

    /**
     * Get the value of nomUtilisateur
     *
     * @return string
     */
    public function getNomUtilisateur(): string
    {
        return $this->nomUtilisateur;
    }

    /**
     * Set the value of nomUtilisateur
     *
     * @param string $nomUtilisateur
     *
     * @return self
     */
    public function setNomUtilisateur(string $nomUtilisateur): self
    {
        $nomUtilisateur = trim($nomUtilisateur);
        if (empty($nomUtilisateur) || strlen($nomUtilisateur) > 50)
            throw new Exception("Le nom d'utilisateur '$nomUtilisateur' doit être entre 1 ET 50 caractères.");
        $this->nomUtilisateur = $nomUtilisateur;
        return $this;
    }

    /**
     * Get the value of prenom
     *
     * @return string
     */
    public function getPrenom(): string
    {
        return $this->prenom;
    }

    /**
     * Set the value of prenom
     *
     * @param string $prenom
     *
     * @return self
     */
    public function setPrenom(string $prenom): self
    {
        $prenom = trim($prenom);
        if (empty($prenom) || strlen($prenom) > 50)
            throw new Exception("Le prenom '$prenom' doit être entre 1 ET 50 caractères.");
        $this->prenom = $prenom;
        return $this;
    }

    /**
     * Get the value of nom
     *
     * @return string
     */
    public function getNom(): string
    {
        return $this->nom;
    }

    /**
     * Set the value of nom
     *
     * @param string $nom
     *
     * @return self
     */
    public function setNom(string $nom): self
    {
        $nom = trim($nom);
        if (empty($nom) || strlen($nom) > 50)
            throw new Exception("Le nom '$nom' doit être entre 1 ET 50 caractères.");
        $this->nom = $nom;
        return $this;
    }

    /**
     * Get the value of courriel
     *
     * @return string
     */
    public function getCourriel(): string
    {
        return $this->courriel;
    }

    /**
     * Set the value of courriel
     *
     * @param string $courriel
     *
     * @return self
     */
    public function setCourriel(string $courriel): self
    {
        $courriel = trim($courriel);
        if (strlen($courriel) > 255 || !filter_var($courriel, FILTER_VALIDATE_EMAIL))
            throw new Exception("Le courriel '$courriel' n'est pas de format valide.");
        $this->courriel = $courriel;
        return $this;
    }

    /**
     * Get the value of roleId
     *
     * @return int
     */
    public function getRoleId(): int
    {
        return $this->roleId;
    }

    /**
     * Set the value of roleId
     *
     * @param int $roleId
     *
     * @return self
     */
    public function setRoleId(int $roleId): self
    {
        $this->roleId = $roleId;
        return $this;
    }

    /**
     * Get the value of role
     *
     * @return ?Role
     */
    public function getRole(): ?Role
    {
        return $this->role;
    }

    /**
     * Set the value of role
     *
     * @param ?Role $role
     *
     * @return self
     */
    public function setRole(?Role $role): self
    {
        $this->role = $role;
        return $this;
    }

    /**
     * Get the value of cheminAvatar
     *
     * @return ?string
     */
    public function getCheminAvatar(): ?string
    {
        return $this->cheminAvatar;
    }

    /**
     * Set the value of cheminAvatar
     *
     * @param ?string $cheminAvatar
     *
     * @return self
     */
    public function setCheminAvatar(?string $cheminAvatar): self
    {
        $this->cheminAvatar = $cheminAvatar;
        return $this;
    }

    /**
     * Get the value of hash
     *
     * @return string
     */
    public function getHash(): string
    {
        return $this->hash;
    }

    /**
     * Set the value of hash
     *
     * @param string $hash
     *
     * @return self
     */
    public function setHash(string $hash): self
    {
        $this->hash = $hash;
        return $this;
    }
}
