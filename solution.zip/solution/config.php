<?php
require_once 'autoloader.php';

const NOM_BD = "blogue";
const NOM_UTILISATEUR_BD = "etd";
define("MDP_BD", "etd123"); // Autre façon de déclarer un constante

$config = new ConfigDao(NOM_BD, NOM_UTILISATEUR_BD, MDP_BD);